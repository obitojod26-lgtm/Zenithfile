package com.zenith.filemanager

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import java.text.DateFormat
import java.util.Date
import java.util.Locale

private val palettes = listOf(
    Color(0xFF6750A4), Color(0xFF006C60), Color(0xFF1565C0),
    Color(0xFF9C4146), Color(0xFF7A5900), Color(0xFF37474F)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZenithFilesApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ZenithFilesApp() {
    val context = LocalContext.current
    var rootUri by remember { mutableStateOf<Uri?>(null) }
    var rootFolder by remember { mutableStateOf<DocumentFile?>(null) }
    var currentFolder by remember { mutableStateOf<DocumentFile?>(null) }
    var entries by remember { mutableStateOf(emptyList<DocumentFile>()) }
    var query by remember { mutableStateOf("") }
    var grid by remember { mutableStateOf(false) }
    var dark by remember { mutableStateOf(true) }
    var accent by remember { mutableIntStateOf(0) }
    var fontChoice by remember { mutableIntStateOf(0) }
    var backgroundChoice by remember { mutableIntStateOf(0) }
    var sortChoice by remember { mutableIntStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }
    var showCreate by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf<DocumentFile?>(null) }
    var showDetails by remember { mutableStateOf<DocumentFile?>(null) }
    var nameInput by remember { mutableStateOf("") }
    var folderLabel by remember { mutableStateOf("Selected storage") }
    var refresh by remember { mutableIntStateOf(0) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {}
            rootUri = uri; rootFolder = DocumentFile.fromTreeUri(context, uri); currentFolder = rootFolder; folderLabel = rootFolder?.name ?: "Selected storage"; refresh++
        }
    }
    val bg = if (dark) listOf(Color(0xFF101116), Color(0xFF171126), Color(0xFF101B2B), Color(0xFF10201D), Color(0xFF202027))[backgroundChoice] else listOf(Color(0xFFF5F3FA), Color(0xFFF1ECFA), Color(0xFFEAF2FA), Color(0xFFEAF4EF), Color(0xFFF8F0E5))[backgroundChoice]
    val surface = if (dark) Color(0xFF1B1C22) else Color.White
    val text = if (dark) Color(0xFFF1EFF7) else Color(0xFF1B1B20)
    val muted = if (dark) Color(0xFFB8B5C2) else Color(0xFF66636D)
    val primary = palettes[accent]
    val family = when (fontChoice) { 1 -> FontFamily.Serif; 2 -> FontFamily.Monospace; else -> FontFamily.SansSerif }

    LaunchedEffect(currentFolder, refresh, sortChoice) {
        entries = currentFolder?.listFiles()?.toList()?.sortedWith(
            when (sortChoice) {
                1 -> compareBy<DocumentFile> { it.name?.lowercase(Locale.getDefault()) ?: "" }
                2 -> compareByDescending<DocumentFile> { it.lastModified() }
                3 -> compareBy<DocumentFile> { it.isDirectory }
                else -> compareByDescending<DocumentFile> { it.isDirectory }.thenBy { it.name?.lowercase(Locale.getDefault()) ?: "" }
            }
        ) ?: emptyList()
    }

    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = primary, background = bg, surface = surface) else lightColorScheme(primary = primary, background = bg, surface = surface)) {
        Scaffold(containerColor = bg, topBar = {
            TopAppBar(
                title = { Column { Text("Zenith Files", fontWeight = FontWeight.Bold, fontFamily = family); Text(folderLabel, fontSize = 11.sp, color = muted) } },
                navigationIcon = { Icon(Icons.Default.FolderCopy, contentDescription = null, tint = primary, modifier = Modifier.padding(start = 14.dp).size(26.dp)) },
                actions = {
                    IconButton(onClick = { grid = !grid }) { Icon(if (grid) Icons.Default.ViewList else Icons.Default.GridView, contentDescription = "Toggle layout") }
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Tune, contentDescription = "Appearance and settings") }
                }, colors = TopAppBarDefaults.topAppBarColors(containerColor = bg, titleContentColor = text)
            )
        }, floatingActionButton = {
            if (rootUri != null) FloatingActionButton(onClick = { nameInput = ""; showCreate = true }, containerColor = primary, contentColor = Color.White) { Icon(Icons.Default.Add, contentDescription = "Create folder") }
        }) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(query, { query = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("Search files and folders…") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(18.dp))
                    Spacer(Modifier.width(8.dp))
                    IconButton(onClick = { picker.launch(null) }) { Icon(Icons.Default.FolderOpen, "Choose folder", tint = primary) }
                }
                if (rootUri == null) {
                    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Icon(Icons.Default.FolderSpecial, null, tint = primary, modifier = Modifier.size(76.dp))
                        Spacer(Modifier.height(18.dp)); Text("Your files, your style.", color = text, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = family)
                        Spacer(Modifier.height(8.dp)); Text("Choose a folder or storage location to start browsing. Android will ask you to grant access.", color = muted)
                        Spacer(Modifier.height(20.dp)); Button(onClick = { picker.launch(null) }) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Choose storage") }
                    }
                } else {
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip(onClick = { currentFolder = rootFolder }, label = { Text("Storage root") }, leadingIcon = { Icon(Icons.Default.Home, null) })
                        AssistChip(onClick = { sortChoice = (sortChoice + 1) % 4 }, label = { Text(listOf("Name / folders", "Name A–Z", "Recently changed", "Files first")[sortChoice]) }, leadingIcon = { Icon(Icons.Default.Sort, null) })
                        AssistChip(onClick = { refresh++ }, label = { Text("Refresh") }, leadingIcon = { Icon(Icons.Default.Refresh, null) })
                    }
                    val shown = entries.filter { it.name.orEmpty().contains(query, ignoreCase = true) }
                    if (shown.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(if (query.isBlank()) "This folder is empty" else "No matching files", color = muted) }
                    } else if (grid) {
                        LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(shown, key = { it.uri.toString() }) { file ->
                                FileRow(file, true, surface, text, muted, primary, family,
                                    onOpen = { if (file.isDirectory) currentFolder = file else openFile(context, file) },
                                    onMore = { showDetails = file }, onRename = { nameInput = file.name ?: ""; showRename = file },
                                    onDelete = { file.delete(); refresh++ }, onShare = { shareFile(context, file) })
                            }
                        }
                    } else LazyColumn(contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        items(shown, key = { it.uri.toString() }) { file ->
                            FileRow(file, false, surface, text, muted, primary, family,
                                onOpen = { if (file.isDirectory) currentFolder = file else openFile(context, file) },
                                onMore = { showDetails = file }, onRename = { nameInput = file.name ?: ""; showRename = file },
                                onDelete = { file.delete(); refresh++ }, onShare = { shareFile(context, file) })
                        }
                    }
                }
            }
        }

        if (showCreate) AlertDialog(onDismissRequest = { showCreate = false }, title = { Text("New folder") }, text = { OutlinedTextField(nameInput, { nameInput = it }, label = { Text("Folder name") }, singleLine = true) }, confirmButton = { TextButton(onClick = { if (nameInput.isNotBlank()) { currentFolder?.createDirectory(nameInput.trim()); refresh++ }; showCreate = false }) { Text("Create") } }, dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Cancel") } })
        showRename?.let { file -> AlertDialog(onDismissRequest = { showRename = null }, title = { Text("Rename") }, text = { OutlinedTextField(nameInput, { nameInput = it }, singleLine = true) }, confirmButton = { TextButton(onClick = { if (nameInput.isNotBlank()) file.renameTo(nameInput.trim()); refresh++; showRename = null }) { Text("Save") } }, dismissButton = { TextButton(onClick = { showRename = null }) { Text("Cancel") } }) }
        showDetails?.let { file -> AlertDialog(onDismissRequest = { showDetails = null }, title = { Text(file.name ?: "Details") }, text = { Column { Text(if (file.isDirectory) "Folder" else "File"); Text("Size: ${if (file.isDirectory) "—" else formatSize(file.length())}"); Text("Modified: ${DateFormat.getDateTimeInstance().format(Date(file.lastModified()))}"); Text(file.type ?: "Unknown type") } }, confirmButton = { TextButton(onClick = { showDetails = null }) { Text("Close") } }, dismissButton = { Row { TextButton(onClick = { showDetails = null; nameInput = file.name ?: ""; showRename = file }) { Text("Rename") }; TextButton(onClick = { shareFile(context, file); showDetails = null }) { Text("Share") }; TextButton(onClick = { file.delete(); refresh++; showDetails = null }) { Text("Delete") } } }) }
        if (showSettings) AlertDialog(onDismissRequest = { showSettings = false }, title = { Text("Personalize Zenith Files") }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Dark theme", Modifier.weight(1f)); Switch(dark, { dark = it }) }
                Text("Accent colour"); Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { palettes.forEachIndexed { i, c -> Box(Modifier.size(32.dp).clip(CircleShape).background(c).border(if (accent == i) 3.dp else 0.dp, text, CircleShape).clickable { accent = i }) } }
                Text("Font style"); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Sans", "Serif", "Mono").forEachIndexed { i, s -> FilterChip(selected = fontChoice == i, onClick = { fontChoice = i }, label = { Text(s) }) } }
                Text("Background colour")
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    val backgroundSwatches = if (dark) listOf(Color(0xFF101116), Color(0xFF171126), Color(0xFF101B2B), Color(0xFF10201D), Color(0xFF202027)) else listOf(Color(0xFFF5F3FA), Color(0xFFF1ECFA), Color(0xFFEAF2FA), Color(0xFFEAF4EF), Color(0xFFF8F0E5))
                    backgroundSwatches.forEachIndexed { i, c -> Box(Modifier.size(30.dp).clip(CircleShape).background(c).border(if (backgroundChoice == i) 3.dp else 1.dp, primary, CircleShape).clickable { backgroundChoice = i }) }
                }
                Text("Storage access is granted folder-by-folder using Android's system picker.", color = muted, fontSize = 12.sp)
            }
        }, confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Done") } })
    }
}

@Composable
private fun FileRow(file: DocumentFile, grid: Boolean, surface: Color, text: Color, muted: Color, primary: Color, family: FontFamily,
                    onOpen: () -> Unit, onMore: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit, onShare: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth().clickable { onOpen() }, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = surface)) {
        if (grid) {
            Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(54.dp).clip(RoundedCornerShape(16.dp)).background(primary.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                    Icon(when { file.isDirectory -> Icons.Default.Folder; file.type?.startsWith("image/") == true -> Icons.Default.Image; file.type?.startsWith("video/") == true -> Icons.Default.Movie; file.type?.startsWith("audio/") == true -> Icons.Default.AudioFile; else -> Icons.Default.InsertDriveFile }, null, tint = primary, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.height(8.dp))
                Text(file.name ?: "Unnamed", color = text, fontWeight = FontWeight.Medium, fontFamily = family, maxLines = 1, fontSize = 13.sp)
                Text(if (file.isDirectory) "Folder" else formatSize(file.length()), color = muted, fontSize = 10.sp)
                Box(Modifier.align(Alignment.End)) {
                    IconButton(onClick = { menu = true }, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.MoreVert, "More actions", tint = muted) }
                    FileActionsMenu(menu, { menu = false }, onMore, onRename, onShare, onDelete)
                }
            }
        } else {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(primary.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                    Icon(when { file.isDirectory -> Icons.Default.Folder; file.type?.startsWith("image/") == true -> Icons.Default.Image; file.type?.startsWith("video/") == true -> Icons.Default.Movie; file.type?.startsWith("audio/") == true -> Icons.Default.AudioFile; else -> Icons.Default.InsertDriveFile }, null, tint = primary)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(file.name ?: "Unnamed", color = text, fontWeight = FontWeight.Medium, fontFamily = family, maxLines = 1)
                    Text(if (file.isDirectory) "Folder" else "${formatSize(file.length())}  ·  ${file.type ?: "File"}", color = muted, fontSize = 11.sp, maxLines = 1)
                }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "More actions", tint = muted) }
                    FileActionsMenu(menu, { menu = false }, onMore, onRename, onShare, onDelete)
                }
            }
        }
    }
}

@Composable
private fun FileActionsMenu(expanded: Boolean, dismiss: () -> Unit, details: () -> Unit, rename: () -> Unit, share: () -> Unit, delete: () -> Unit) {
    DropdownMenu(expanded = expanded, onDismissRequest = dismiss) {
        DropdownMenuItem(text = { Text("Details") }, leadingIcon = { Icon(Icons.Default.Info, null) }, onClick = { dismiss(); details() })
        DropdownMenuItem(text = { Text("Rename") }, leadingIcon = { Icon(Icons.Default.Edit, null) }, onClick = { dismiss(); rename() })
        DropdownMenuItem(text = { Text("Share") }, leadingIcon = { Icon(Icons.Default.Share, null) }, onClick = { dismiss(); share() })
        DropdownMenuItem(text = { Text("Delete") }, leadingIcon = { Icon(Icons.Default.Delete, null) }, onClick = { dismiss(); delete() })
    }
}

private fun openFile(context: android.content.Context, file: DocumentFile) {
    try {
        val intent = Intent(Intent.ACTION_VIEW).apply { setDataAndType(file.uri, file.type ?: "*/*"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        context.startActivity(Intent.createChooser(intent, "Open with"))
    } catch (_: Exception) { }
}
private fun shareFile(context: android.content.Context, file: DocumentFile) {
    try {
        val intent = Intent(Intent.ACTION_SEND).apply { type = file.type ?: "*/*"; putExtra(Intent.EXTRA_STREAM, file.uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        context.startActivity(Intent.createChooser(intent, "Share file"))
    } catch (_: Exception) { }
}
private fun formatSize(size: Long): String = when {
    size < 1024 -> "$size B"
    size < 1024 * 1024 -> String.format(Locale.getDefault(), "%.1f KB", size / 1024.0)
    size < 1024L * 1024L * 1024L -> String.format(Locale.getDefault(), "%.1f MB", size / (1024.0 * 1024.0))
    else -> String.format(Locale.getDefault(), "%.2f GB", size / (1024.0 * 1024.0 * 1024.0))
}
