# Zenith Files — Android file manager starter

A modern Jetpack Compose file manager project configured for Android 14 (targetSdk 34), with Android 8.0+ support.

## Included in this first build
- Folder selection through Android Storage Access Framework (SAF); no broad all-files permission is requested.
- Browse folders and files, search current folder, refresh, and sort.
- Open files with compatible apps and share files.
- Create folders, rename, delete, and view basic file details.
- List/grid toggle control, dark/light theme, six accent colours, and Sans/Serif/Monospace font choices.
- Material 3 interface with adaptive system-safe storage access.

## Build APK
Open this folder in Android Studio (Ladybug or newer), allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

Build requirements: JDK 17, Android SDK Platform 35, Android Gradle Plugin 8.7.3. `targetSdk = 34` is intentional for the requested Android 14 baseline; it can run on newer Android versions too.

## Important scope notes
This is a first functional foundation, not yet a full replacement for OEM Files apps. Access is limited to the folder tree the user explicitly selects. Android restricts some protected locations (including parts of `Android/data` and `Android/obb`). Copy/move, archive extraction, recycle bin, cloud providers, thumbnails, media categories, and wallpaper image import are planned follow-up features.
